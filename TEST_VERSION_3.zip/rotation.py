import math
def rotation(a,b):
    ax, ay = a
    bx, by = b
    angle = math.degrees(math.atan2(bx-ax,by-ay))+180
    if -90<angle<90:
        return angle
    else:
        return angle-360
