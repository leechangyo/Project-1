import cv2
import numpy as np


class multi_detect():
    #camera variables
    cam_mtx=None
    dist=None
    newcam_mtx=None
    roi=None
    rvec1=None
    tvec1=None
    R_mtx=None
    Rt=None
    P_mtx=None

    #images
    img=None

    # save shape points
    #detected_points=[]

    # obj_count

    def __init__(self):


        savedir="camera_data/"

        #self.imageRec=image_recognition_singlecam.image_recognition(True,False,imgdir,imgdir,True,True)

        self.cam_mtx=np.load(savedir+'cam_mtx.npy')
        self.dist=np.load(savedir+'dist.npy')
        self.newcam_mtx=np.load(savedir+'newcam_mtx.npy')
        self.roi=np.load(savedir+'roi.npy')
        self.rvec1=np.load(savedir+'rvec1.npy')
        self.tvec1=np.load(savedir+'tvec1.npy')
        self.R_mtx=np.load(savedir+'R_mtx.npy')
        self.Rt=np.load(savedir+'Rt.npy')
        self.P_mtx=np.load(savedir+'P_mtx.npy')

        s_arr=np.load(savedir+'s_arr.npy')
        self.scalingfactor=s_arr[0]

        self.inverse_newcam_mtx = np.linalg.inv(self.newcam_mtx)
        self.inverse_R_mtx = np.linalg.inv(self.R_mtx)

        #Valid contour Parameters limits
        self.MIN_AREA=900 #30x30
        self.MAX_AREA=9000 #300x300
        #aspect ratio width/height
        self.MIN_ASPECTRATIO=1/2
        self.MAX_ASPECTRATIO=2

    def undistort_image(self,image):
        image_undst = cv2.undistort(image, self.cam_mtx, self.dist, None, self.newcam_mtx)

        return image_undst

    def setLabel(self,image, str_, contour):

        (text_width, text_height), baseline = cv2.getTextSize(str_, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 1)
        x,y,width,height = cv2.boundingRect(contour)
        pt_x = x+int((width-text_width)/2)
        pt_y = y+int((height + text_height)/2)
        cx = self.truncate(pt_x,2)
        cy = self.truncate(pt_y,2)
        cv2.rectangle(image, (pt_x, pt_y+baseline), (pt_x+text_width, pt_y-text_height), (200,200,200), cv2.FILLED)
        cv2.putText(image, str_, (pt_x, pt_y), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,0), 1, 8)
        return (str_, x, y, width, height, cx, cy)

    def detect(self, image, object_contour):

        width, height, channel = image.shape
        contours_validindex= self.identify_validcontours(object_contour,height,width)
        obj_count = len(contours_validindex)
        detected_points = []

        if (obj_count>0):

            for cnt in range(0,obj_count):
                cnt=object_contour[contours_validindex[cnt]]
                size = len(cnt)
                epsilon = 0.04 * cv2.arcLength(cnt, True)
                approx = cv2.approxPolyDP(cnt, epsilon, True)
                size = len(approx)
                area = cv2.contourArea(cnt)
                # DISCARD noise with measure if area not within parameters
                if area >= 500 and area <=4000:
                    cv2.line(image, tuple(approx[0][0]), tuple(approx[size-1][0]), (0, 255, 0), 3)
                    for k in range(size-1):
                        cv2.line(image, tuple(approx[k][0]), tuple(approx[k+1][0]), (0, 255, 0), 3)
                    if cv2.isContourConvex(approx):
                        if size == 3:
                            (str_, x, y, w, h, cx, cy)= self.setLabel(image, "triangle", cnt)
                            points=[str_, x, y, w, h, cx, cy]
                            detected_points.append(points)
                        elif size == 4:
                            (str_, x, y, w, h, cx, cy) = self.setLabel(image, "rectangle", cnt)
                            points=[str_, x, y, w, h, cx, cy]
                            detected_points.append(points)
                        elif size == 5:
                            (str_, x, y, w, h, cx, cy) = self.setLabel(image, "pentagon", cnt)
                            points=[str_, x, y, w, h, cx, cy]
                            detected_points.append(points)
                        elif size == 6:
                            (str_, x, y, w, h, cx, cy) = self.setLabel(image, "hextagon", cnt)
                            points=[str_, x, y, w, h, cx, cy]
                            detected_points.append(points)
                        else:
                            (x,y),radius =cv2.minEnclosingCircle(approx)
                            if radius >= 10 and radius <=50:
                                (str_, x, y, w, h, cx, cy) = self.setLabel(image, "Circle",cnt)
                                points=[str_, x, y, w, h, cx, cy]
                                detected_points.append(points)
                            else:
                                continue

        return obj_count, detected_points

    def detect_xyz(self,obj_count, detected_points,image,distance,calcXYZ=True,calcarea=False):
        XYZ=[]
        adj_XYZ=[]
        #print(obj_count)
        if (obj_count>0):
            for i in range(0,len(detected_points)):
                if detected_points[i][0] == 'triangle':
                    shape = 0
                elif detected_points[i][0] == 'rectangle':
                    shape = 1
                elif detected_points[i][0] == 'pentagon':
                    shape = 2
                elif detected_points[i][0] == 'hextagon':
                    shape = 3
                else:
                    detected_points[i][0] == 'Circle'
                    shape = 4
                x=detected_points[i][1]
                y=detected_points[i][2]
                w=detected_points[i][3]
                h=detected_points[i][4]
                cx=detected_points[i][5]
                cy=detected_points[i][6]
                cv2.putText(image,"cx_,cy_: ={}, {}".format(self.truncate(cx,2),self.truncate(cy,2)),(x,y+h+28),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),1)
                if calcXYZ==True:
                    # Convert to XYZ real coordinate
                    shape_XYZ = self.calculate_XYZ(cx,cy)
                    shape_XYZ = np.insert(shape_XYZ,0,shape)
                    # value of list at the beggining
                    XYZ.append(shape_XYZ)
                    XYZ[i][1]=XYZ[i][1]+6
                    XYZ[i][2]=XYZ[i][2]+8
                    XYZ[i][3]=distance
                    adj_XYZ.append(XYZ)
                    cv2.putText(image,"X_,Y_: "+str(self.truncate(XYZ[i][1],2))+","+str(self.truncate(XYZ[i][2],2)),(x,y+h+14),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),1)
                if calcarea==True:
                    cv2.putText(image,"area: "+str(self.truncate(w*h,2)),(x,y-12),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),1)
        return adj_XYZ

    def calculate_XYZ(self,u,v):

        #Solve: From Image Pixels, find World Points

        uv_1=np.array([[u,v,1]], dtype=np.float32)
        uv_1=uv_1.T
        suv_1=self.scalingfactor*uv_1
        xyz_c=self.inverse_newcam_mtx.dot(suv_1)
        xyz_c=xyz_c-self.tvec1
        XYZ=self.inverse_R_mtx.dot(xyz_c)
        return XYZ

    def truncate(self, n, decimals=0):
        n=float(n)
        multiplier = 10 ** decimals
        return int(n * multiplier) / multiplier

    def identify_validcontours(self,cnt,height,width):
        #helps discard noise on contour detection.
        #this is calibrated for Legos in this example
        contours_validindex=[]
        contour_index=-1
        for i in cnt:
            contour_index=contour_index+1
            ca=cv2.contourArea(i)
            # Calculate W/H Ratio
            x,y,w,h = cv2.boundingRect(i)
            aspect_ratio = float(w)/h
            # Flag as edge_noise if the object is at a Corner
            edge_noise=False
            if x==0:
                edge_noise=True
            if y==0:
                edg_noise =True
            if (x+w)==width:
                edge_noise=True
            if (y+h)==height:
                edge_noise=True
            # DISCARD noise with measure if area not within parameters
            if ca>self.MIN_AREA and ca<self.MAX_AREA:

                # DISCARD as noise on ratio
                if aspect_ratio>=self.MIN_ASPECTRATIO and aspect_ratio<=self.MAX_ASPECTRATIO:

                    # DISCARD if at the Edge
                    if edge_noise==False:
                         contours_validindex.append(contour_index)

        return contours_validindex
