from scipy.spatial import distance as dist
import numpy as np
import imutils
import cv2

def dist(KNOWN_AREA,area,KNOWN_DISTANCE):
    if area !=0:
        x = KNOWN_AREA/area
        distance = KNOWN_DISTANCE*x
        return distance
