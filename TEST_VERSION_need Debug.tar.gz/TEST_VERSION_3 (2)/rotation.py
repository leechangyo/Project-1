import math

def rotation(a,b):
    ax, ay = a
    bx, by = b
    angle = math.degrees(math.atan2(bx-ax,by-ay))
    radian = (angle * 3.14)/180
    return  radian, angle
    #if -90<angle<90:
    #    radian = (angle * 3.14)/180
    #    return radian, angle
    #else:
    #    radian = ((angle-360)*3.14)/180
    #    return radian, (angle-360)
