 #!/usr/bin/env python
import cv2
import numpy as np
import imutils
from scipy.spatial import distance as dist
import math
from motion_background import calc_accum
from segment import segment
from detect import detect
from centroid import centroid
from multi_detect import multi_detect
from rotation import rotation
import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from std_msgs.msg import String
from geometry_msgs.msg import Pose
from cv_bridge import CvBridge, CvBridgeError
import tf
import tf2_ros
from geometry_msgs.msg import TransformStamped
class video():

    def __init__(self):
        # Creates a node with name 'XYZ_COORDINATE' and make sure it is a unique node
        rospy.init_node('XYZ_COORDINATE', anonymous=True)
        
        self.image_pub =rospy.Publisher("image_topic_2",Image,queue_size=10)
        self.bridge = CvBridge()
        
        self.pose_publisher = rospy.Publisher('/object/pose',Pose, queue_size=10)
        
         # Publisher which will publish to the topic '/jaka/cmd_vel'.
        self.velocity_publisher = rospy.Publisher('/jaka/cmd_vel',Twist,queue_size=10)

        self.pose = Pose()
        self.rate = rospy.Rate(10)
    ###################################################################################


    ###################################################################################
    # Manually set up our ROI for grabbing the hand.
    # Feel free to change these. I just chose the top right corner for filming
        global cam, roi_top, roi_bottom, roi_right, roi_left, roi_top2,roi_bottom2, accumulated_weight
        global accumulated_weight2, accumulated_weight3, background_calc
        roi_top = 20
        roi_bottom = 140
        roi_right = 260
        roi_left = 380

    # ROI 2
        roi_top2 = 340
        roi_bottom2 = 460
        # CAMERA SIZE
        cam = cv2.VideoCapture(0)
        cam.set(3,640)
        cam.set(4,480)
    # Intialize a frame count
        
    # background calc in real time
    # Start with a halfway point between 0 and 1 of accumulated weight
        accumulated_weight = 0.7
        accumulated_weight2 = 0.7
        accumulated_weight3 = 0.7
        background_calc = calc_accum()

    def update_pose(self, data):
        """Callback function which is called when a new message of type Pose is
        received by the subscriber."""
        self.pose = data
        self.pose.position.x = round(self.pose.position.x, 4)
        self.pose.position.y = round(self.pose.position.y, 4)
        self.pose.position.z = round(self.pose.position.z, 4)
        print(self.pose)

    def constrain(self,x,y,z,rotation):
        if 12<=x<=14:
            x = True
            if 15<=y<=17:
                y = True
                if 40<=z<= 50:
                    z = True
                    if -2.5<=rotation<=2.5:
                        rotation = True
                        return True
                    else:
                        return False

    def XYZ_Coordinate(self,object):
        num_frames = 0
        goal_pose = Pose()

        t2 = TransformStamped()
        t2.header.stamp = rospy.Time.now()
        t2.header.frame_id = "base_frame"
        t2.child_frame_id = "camera_frame"
        while True:
            # get the current frame
            ret, frame = cam.read()
            # flip the frame so that it is not the mirror view
            #frame = cv2.flip(frame, 1)
            # clone the frame
            frame_copy = frame.copy()

            # object detection.
            height = frame_copy.shape[0]
            object_roi_top = height/2
            object_roi_bottom = 640
            object_detect = frame[object_roi_top:object_roi_bottom,:]
            object_gray = cv2.cvtColor(object_detect, cv2.COLOR_BGR2GRAY)
            object_gray = cv2.bilateralFilter(object_gray,3,1000,1000)


        # ROI 1
        # Grab the ROI from the frame(1)
            roi = frame[roi_top:roi_bottom, roi_right:roi_left]
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        # Apply grayscale and blur to ROI
            gray = cv2.GaussianBlur(gray, (5, 5), 0)

        # ROI 2
            roi2 = frame[roi_top2:roi_bottom2, roi_right:roi_left]
            gray2 = cv2.cvtColor(roi2, cv2.COLOR_BGR2GRAY)
            gray2 = cv2.GaussianBlur(gray2, (5, 5), 0)

        # For the first 60 frames we will calculate the average of the background.
            if num_frames < 60:
                background_calc.calc_accum_avg(gray, accumulated_weight)
                background_calc.calc_accum_avg2(gray2, accumulated_weight2)
                #background_calc.calc_accum_avg3(object_gray, accumulated_weight3)
                if num_frames <= 59:
                    cv2.putText(frame_copy, "WAIT! GETTING BACKGROUND AVG.", (1, 470), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
                    cv2.imshow("Vision",frame_copy)
            else:

                # shape detect upper
                upper_shape = segment(gray)
                if upper_shape is not None:
                    upper_thresh, upper_contour,upper_segment, upper_cnts = upper_shape
                    upper_shape_detect,upper_distance = detect(upper_contour)
                    (upper_cX,upper_cY,upper_c) = centroid(upper_cnts)

                    # Draw information
                    cv2.drawContours(frame_copy, [upper_segment+(roi_right,roi_top)], -1, (255,0,0),1)
                    cv2.circle(frame_copy, (upper_cX+roi_right, roi_top+upper_cY),7,(255,0,0),-1)
                    cv2.putText(frame_copy,"upper_shape : "+ str(upper_shape_detect),(1,440),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)

                    cv2.imshow("upper_threshold", upper_thresh)
                    # shape detect bottom
                bottom_shape = segment(gray2)
                if bottom_shape is not None:
                    bottom_thresh, bottom_contour,bottom_segment, bottom_cnts = bottom_shape
                    bottom_shape_detect, bottom_distance= detect(bottom_contour)
                    (bottom_cX,bottom_cY,bottom_c) = centroid(bottom_cnts)

                    # Draw information
                    cv2.drawContours(frame_copy, [bottom_segment + (roi_right, roi_top2)], -1, (255,0,0),1)
                    cv2.putText(frame_copy,"bottom_shape : "+ str(bottom_shape_detect),(1,460),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
                    cv2.circle(frame_copy, (bottom_cX+roi_right, roi_top2+bottom_cY),7,(255,0,0),-1)
                    cv2.imshow("bottom_threshold", bottom_thresh)



                # distance
                cv2.putText(frame_copy,"Object_DISTANCE={} ".format(bottom_distance),(1,400),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
                

                # rotation
                upper_c = (upper_cX+roi_right, roi_top+upper_cY)
                bottom_c = (bottom_cX+roi_right, roi_top2+bottom_cY)
                radian ,angles = rotation(bottom_c,upper_c)
                if angles>0:
                    cv2.putText(frame_copy,"rotate={}, clockwise".format(angles),(1,420),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
                else:
                    cv2.putText(frame_copy,"rotate={}, counterclockwise".format(angles),(1,420),cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)



                object_detect = segment(object_gray,threshold=120)
                if object_detect is not None:
                    object_thresh, object_contour,object_segment, object_cnts =  object_detect
                    multi_obejct_detect=multi_detect()
                    obj_count, detected_points,=multi_obejct_detect.detect(frame_copy[object_roi_top:object_roi_bottom,:],object_contour)
                    XYZ = multi_obejct_detect.detect_xyz(obj_count, detected_points, frame_copy[object_roi_top:object_roi_bottom,:], bottom_distance,object)
                    # Get the object position
                    cv2.imshow('test',object_thresh)
                    if XYZ == None:
                        pass
                    else:
                        goal_pose.position.x = XYZ[0]
                        goal_pose.position.y = XYZ[1]
                        goal_pose.position.z = XYZ[2]
                        
                        #
                        t2.transform.translation.x = XYZ[0]
                        t2.transform.translation.y = XYZ[1]
                        t2.transform.translation.z = XYZ[2]
                        q2 = tf.transformations.quaternion_about_axis(radian, (0,0,1))
                        t2.transform.rotation.x = q2[0]
                        t2.transform.rotation.y = q2[1]
                        t2.transform.rotation.z = q2[2]
                        t2.transform.rotation.w = q2[3]
                        br.sendTransform(t2)
                        # quaternion
                        goal_pose.orientation.x = q2[0]
                        goal_pose.orientation.y = q2[1]
                        goal_pose.orientation.z = q2[2]
                        goal_pose.orientation.w = q2[3]
                        #publish
                        self.pose_publisher.publish(goal_pose)
                        #contrain
                        goal_contrain=self.constrain(XYZ[0],XYZ[1],XYZ[2],angles)
                        #while goal_contrain != True:
                                         



    # Draw ROI Rectangle on frame copy
            cv2.rectangle(frame_copy, (roi_left, roi_top), (roi_right, roi_bottom), (0,0,255), 5)
            cv2.rectangle(frame_copy, (roi_left, roi_top2), (roi_right, roi_bottom2), (0,0,255),5)
    # Center
            #cv2.circle(frame_copy,(410,242),7,(0,0,255),5)
            cv2.circle(frame_copy,(320,240),7,(0,0,255),5)

    # increment the number of frames for tracking
            num_frames += 1

    # Display the frame with segmented hand
            #publish image
            try:
                self.image_pub.publish(self.bridge.cv2_to_imgmsg(frame_copy,"bgr8"))
            except CvBridgeError as e:
                print(e)

            
            cv2.imshow("Vision", frame_copy)


    # Close windows with Esc
            k = cv2.waitKey(1) & 0xFF

            if k == 27:
                break
        cam.release()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    try:
        x = video()
        br = tf2_ros.TransformBroadcaster()
        rospy.sleep(0.5)
        # GET the input from the user.
        print("what you looking for?")
        object = input("triangle:0, rectangle:1, pentagon:2, hexagon:3, Circle:4, end:5 = ")
        x.XYZ_Coordinate(object)
    except rospy.ROSInterruptException:
        pass

        
